export class User {
  _id?: string;
  user_id?: string;
  name?: string;
  email?: string;
  team?: string;
  password?: string;
}

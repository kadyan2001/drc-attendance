export class Attendence {
  user: object;
  out_time: object;
  status: 'present' | 'absent';
}
